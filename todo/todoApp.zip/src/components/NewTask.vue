<template>
  <div class="newTask">
    <input v-model="text" type="text" placeholder="Введите текст">
    <button @click="$emit('btn', text)">Добавить</button>
  </div>
</template>

<script>
export default {
  name: 'NewTask',
  data() {
    return {
      text: ''
    }
  },
  methods: {
    
  }
}

</script>

<style lang="scss">
.newTask{
  width: 900px;
  display: flex;
  gap: 20px;
  margin: auto;
  justify-content: center;
}
input{
  width: 250px;
  padding: 13px;
}
</style>